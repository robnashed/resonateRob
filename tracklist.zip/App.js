import React from 'react';
import { StyleSheet, Text, View, SafeAreaView,
  TextInput,
  Platform,
  StatusBar,
  ScrollView,
  Image } from 'react-native';


import Icon from 'react-native-vector-icons/Ionicons'


class App extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        <ScrollView contentContainerStyle={styles.contentContainer} scrollEventThrottle={16}>
            

            <View style={{flex:1, backgroundColor:'white',paddingTop: 10, paddingBottom: 10}}>
            <Text>Artist - Title</Text>
            </View>
            <View style={{flex:1, backgroundColor:'white',paddingTop: 10, paddingBottom: 10}}>
            <Text>Artist - Title</Text>
            </View>
            <View style={{flex:1, backgroundColor:'white',paddingTop: 10, paddingBottom: 10}}>
            <Text>Artist - Title</Text>
            </View>
            <View style={{flex:1, backgroundColor:'white',paddingTop: 10, paddingBottom: 10}}>
            <Text>Artist - Title</Text>
            </View>
            
        </ScrollView>
      </View>
    );
  }
}

export default App;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
